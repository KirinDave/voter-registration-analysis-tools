<?php
/*
Summarized PA county registration data by precint

$inputfilename = $argv[1];

0 ID Number
6 Gender
7 DOB
8 Registration Date
9 Voter Status
10 Status Change Date
11 Party Code
17 City
25 Last Vote Date
26 Precinct Code
27 Precinct Split ID

Output format:
County Name	City Name	Precint Code	Precinct Split ID	Number of Registrations	Female	Male	Unknown Gender	Dem	Rep	Lib	Other	


?>