php getallids.php
php getallvoterids.php
php getallfirstnamelastnamedobs.php
php getalllastnamedobs.php
php getallfirstnamedobs.php
php getalladdresses.php

php printstats.php fullids.txt
php printstats.php voterids.txt
php printstats.php firstnamelastnamedobs.txt
php printstats.php lastnamedobs.txt
php printstats.php firstnamedobs.txt 
php printstats.php addresses.txt

zip lists.zip fullids.txt voterids.txt firstnamelastnamedobs.txt lastnamedobs.txt firstnamedobs.txt addresses.txt